
first_number = int(input("what is the 1st number"))
second_number = int(input("what is the 2nd number"))
third_number = int(input("what is the 3d number"))
forth_number = int(input("what is the 4th number"))
fith_number =int(input("what is the 5th number"))
answer = first_number * second_number - third_number + forth_number / fith_number
print(answer)